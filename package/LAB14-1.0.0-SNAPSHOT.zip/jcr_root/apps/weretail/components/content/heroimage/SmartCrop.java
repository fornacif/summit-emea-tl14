import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;

import com.adobe.cq.sightly.WCMUsePojo;

public class SmartCrop extends WCMUsePojo {

	private String assetURL;

	@Override
	public void activate() throws Exception {
		ResourceResolver resourceResolver = getResourceResolver();

		assetURL = getProperties().get("fileReference", String.class);

		Resource metadataResource = resourceResolver.getResource(assetURL + "/jcr:content/metadata");
		ValueMap valueMap = metadataResource.adaptTo(ValueMap.class);

        if (valueMap.containsKey("dam:scene7Domain")) {
            String scene7Domain = valueMap.get("dam:scene7Domain", String.class).trim();
            String scene7File = valueMap.get("dam:scene7File", String.class).trim();

            String smarCropPath = scene7Domain + "is/image/" + scene7File + ":Hero?qlt=90&res_mode=sharp2&op_usm=1.75,0.2,2,0&fit=constrain,1&cache=off";
            URL smartCropURL = new URL(smarCropPath);
            HttpURLConnection huc = (HttpURLConnection) smartCropURL.openConnection();
            int responseCode = huc.getResponseCode();
            if (responseCode == 200) {
                assetURL = smarCropPath;
            }
        }
	}

	public String getAssetURL() {
		return assetURL;
	}
}